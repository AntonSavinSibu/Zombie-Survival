CORRECT skins exported from zombie.py art builders
=====================================================
These PNGs use the SAME _build_gun_art / _build_katana_art functions
and the SAME GUN_SKINS / _SKIN_SPECS color tables as the game.

gun_skins/   — each armory skin as pistol, shotgun, rpg, minigun, plasma + sheet
katana_skins/ — each skin key as normal / fire / haki blade art
class_skins/  — each unlockable class skin using real accent/suit/body colors

Note: the game does not ship separate skin image files; weapons are drawn at runtime.
These are faithful exports of that runtime art.
